package com.safetyGame.desktop.logic;
import com.safetyGame.desktop.condivisi.*;

public class ConnBack{

  public ConnBack(){
    //istanzia le variabili per la connessione al back
  }
  
  public boolean login(String username, String password){
    //chiama le funzioni del back - end
    return false;
  }
  
  public boolean logout(String username){
    //chiama le funzioni del back - end
    return false;
  }
  
  public boolean posticipa(){
    //chiama le funzioni del back - end
    return false;
  }
  
  public boolean recupera(String username){
    //chiama le funzioni del back - end
    return false;
  }
}
