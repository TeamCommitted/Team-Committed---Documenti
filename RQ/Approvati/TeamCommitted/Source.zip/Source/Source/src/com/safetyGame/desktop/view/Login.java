package com.safetyGame.desktop.view;
import com.safetyGame.desktop.logic.ControlLogin;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Login{
    public Login(){
    //istanzia gli oggetti grafici e li mostra
  }

  public void actionPerformed(ActionEvent e){
    //si occupa di gestire gli eventi del click
  }
}
