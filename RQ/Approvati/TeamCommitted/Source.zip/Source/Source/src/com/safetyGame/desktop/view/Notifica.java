package com.safetyGame.desktop.view;
import com.safetyGame.desktop.logic.ControlNotifica;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Notifica{
  public Notifica(){
    //istanzia gli oggetti grafici e li mostra
  }

  public void actionPerformed(ActionEvent e){
    //si occupa di gestire gli eventi del click
  }
}
