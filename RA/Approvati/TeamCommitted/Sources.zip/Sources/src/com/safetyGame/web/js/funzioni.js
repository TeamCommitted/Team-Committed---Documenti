function prova() {
	document.write("ciao");
}